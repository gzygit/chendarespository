#!env perl
#Author: autoCreated
my $para_num = "2";
my %para;
@array_pre_flag = ();
@array_appendix_flag = ();

$para{install_dir} = $ARGV[1];

$pre_cmd{2101} = "cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep -i \"LimitRequestBody\"
";
push(@array_pre_flag, 2101);
$pre_cmd{2103} = "if [ `cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep -i \"<Directory />\"|wc -l` -ge 1 ];
then
testt=`cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep -i -n \"<Directory />\"|tail -1|cut -d\\: -f1`;
testt1=`expr \$testt + 6`;
cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|sed -n \"\$testt,\$testt1\"p;
unset testt testt1;
fi;
";
push(@array_pre_flag, 2103);
$pre_cmd{2105} = "cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep -i  \"Options\"
";
push(@array_pre_flag, 2105);
$pre_cmd{2107} = "cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep -i  \"ErrorDocument\"
";
push(@array_pre_flag, 2107);
$pre_cmd{2109} = "cat $para{install_dir}/conf/httpd.conf |grep -i \"^\\s*user\\b\"
cat $para{install_dir}/conf/httpd.conf |grep -i \"^\\s*group\\b\"
";
push(@array_pre_flag, 2109);
$pre_cmd{2111} = "cat $para{install_dir}/conf/httpd.conf |sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|egrep -i \"Timeout|KeepAlive|KeepAliveTimeout|AcceptFilter\"
";
push(@array_pre_flag, 2111);
$pre_cmd{2113} = "cat $para{install_dir}/conf/httpd.conf |sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|egrep -i \"ServerSignature|ServerTokens\"
";
push(@array_pre_flag, 2113);
$pre_cmd{2115} = "echo \"htdocs=\"`ls $para{install_dir}/htdocs 2>/dev/null|wc -l`
echo \"cgi-bin=\"`ls $para{install_dir}/cgi-bin 2>/dev/null|wc -l`
echo \"manual=\"`ls $para{install_dir}/manual 2>/dev/null|wc -l`
";
push(@array_pre_flag, 2115);
$pre_cmd{2117} = "cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep -i Listen
";
push(@array_pre_flag, 2117);
$pre_cmd{2119} = "cat $para{install_dir}/conf/httpd.conf |sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|egrep -i \"LogLevel|ErrorLog|LogFormat|CustomLog\"
";
push(@array_pre_flag, 2119);
$pre_cmd{2121} = "ls -l $para{install_dir}/conf/httpd.conf
";
push(@array_pre_flag, 2121);
$pre_cmd{2122} = "cat $para{install_dir}/conf/httpd.conf |sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep -i \"ServerRoot\"|awk '{print \$2}'|cut -d\\\" -f2|while read i;do ls -lL \$i;done;
echo \"directory_count=\"`cat $para{install_dir}/conf/httpd.conf |sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep -i \"ServerRoot\"|awk '{print \$2}'|cut -d\\\" -f2|while read i;do ls -lL \$i;done|grep -v \"[r-][w-][x-][r-]-[x-][r-]-[x-]\"|egrep -v \"total|总计\"|wc -l`;
";
push(@array_pre_flag, 2122);
$pre_cmd{2123} = "cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep -i Listen
";
push(@array_pre_flag, 2123);
$pre_cmd{2124} = "ls -lL $para{install_dir}/logs
";
push(@array_pre_flag, 2124);
$pre_cmd{2125} = "precfork_count=`$para{install_dir}/bin/httpd -l|grep prefork.c|wc -l`;
if [ `cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep -i \"<IfModule prefork.c>\"|wc -l` -ge 1 ];
then
testt=`cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep -n -i \"<IfModule prefork.c>\"|tail -1|cut -d\\: -f1`;
testt1=`expr \$testt + 15`;
cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|sed -n \"\$testt,\$testt1\"p;
unset testt,testt1;
fi;
if [ `cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep -i \"<IfModule prefork.c>\"|wc -l` -ge 1 ];
then
testt=`cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep -n -i \"<IfModule prefork.c>\"|tail -1|cut -d\\: -f1`;
testt1=`expr \$testt + 15`;
M_clients=`cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|sed -n \"\$testt,\$testt1\"p|grep MaxClients|awk '{print \$2}'`;
unset testt,testt1;
else
M_clients=0;
fi;
if [ \$precfork_count -ge 1 ];
then
echo \"Apache work mode include the prefork.c module\";
if [ \$M_clients -ne 0 ];
then
if [ \$M_clients -gt 256 ];
then
testt=`cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep -n -i \"<IfModule prefork.c>\"|tail -1|cut -d\\: -f1`;
testt1=`expr \$testt + 15`;
S_Lmits=`cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|sed -n \"\$testt,\$testt1\"p|grep ServerLimit|wc -l`;
unset testt,testt1;
if [ \$S_Lmits -ge 1 ];
then
echo \"The value of MaxClients > 256 And configure the ServerLimit\";
else
echo \"The value of MaxClients > 256 And No configure the ServerLimit\";
fi;
else
echo \"Configure the MaxClients and value < = 256\";
fi;
else
echo \"No configuration the MaxClients\";
fi;
else
echo \"Apache work mode does not include the prefork.c module\"
fi;
unset M_clients S_Lmits precfork_count;
";
push(@array_pre_flag, 2125);
$pre_cmd{2126} = "cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep \"TraceEnable\"
";
push(@array_pre_flag, 2126);
$pre_cmd{2127} = "cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep \"cgi-bin\"
cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep \"LoadModule\\s*cgi_module\"
";
push(@array_pre_flag, 2127);
$pre_cmd{2128} = "$para{install_dir}/bin/httpd -v
";
push(@array_pre_flag, 2128);
$pre_cmd{2129} = "if [ `cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep -i \"<LimitExcept\"|wc -l` -ge 1 ]
then
testt=`cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|grep -n -i \"<LimitExcept\"|tail -1|cut -d\\: -f1`;
testt1=`expr \$testt + 10`;
cat $para{install_dir}/conf/httpd.conf|sed \"/^\\s*#/d\"|sed \"/^\\s*\$/d\"|sed -n \"\$testt,\$testt1\"p;
fi;
";
push(@array_pre_flag, 2129);
$pre_cmd{2130} = "Apache_path=`find / -wholename \"*bin/apachectl\"`
if [ ! \$Apache_path ]; then
echo \"IS NULL\"
else
\$Apache_path -M
\$Apache_path -l
fi
unset Apache_path
";
push(@array_pre_flag, 2130);
$pre_cmd{-11} = "HTTPD_PROCESS=`ps -ef|grep -v grep|grep httpd|awk '{for(i=1;i<=NF;i++) if(\$i~/httpd/) print \$i}'|grep -v \"if(\"|tail -n1`;echo `\$HTTPD_PROCESS -v`;
";
push(@array_pre_flag, -11);
$pre_cmd{-12} = "ps -ef|grep httpd|grep -v grep|wc -l
";
push(@array_pre_flag, -12);
$pre_cmd{-13} = "netstat -anp|grep httpd|grep :`cat $para{install_dir}/conf/httpd.conf|sed '/^\\s*#/d'|sed '/^\\s*\$/d'|grep  'Listen'|awk 'BEGIN{FS=OFS=\":\"}{print \$2}'`|wc -l
";
push(@array_pre_flag, -13);


$pre_cmd{0} = "rm -f /tmp/infile";
push(@array_pre_flag, 0);

sub get_os_info
{
	my %os_info = (
 "initSh"=>"","hostname"=>"","osname"=>"","osversion"=>"");
 $os_info{"initSh"} = `unset LANG`;
	$os_info{"hostname"} = `uname -n`;
	$os_info{"osname"} = `uname -s`;
	$os_info{"osversion"} = `lsb_release -a;cat /etc/issue;cat /etc/redhat-release;uname -a`;
	foreach (%os_info){   chomp;}
	return %os_info;
}

sub add_item
{
	my ($string, $flag, $value)= @_;
	$string .= "\t\t".'<script>'."\n";
	$string .= "\t\t\t<id>$flag</id>\n";
	$string .= "\t\t\t<value><![CDATA[$value]]></value>\n";
	$string .= "\t\t</script>\n";
	return $string;
}
sub generate_xml{
	$ARGC = @ARGV;
	if($ARGC lt 2)
	{
		print qq{usag:uuid.pl IP  Apache��װ·��};
		exit;
	}
	my %os_info = get_os_info();
	my $os_name = $os_info{"osname"};
	my $host_name = $os_info{"hostname"};
	my $os_version = $os_info{"osversion"};
	my $date = `date "+%Y-%m-%d %H:%M:%S"`;
	chomp $date;
	my $coding = `echo \$LANG`;
	my $coding_value = "UTF-8";
	chomp $coding;
	if($coding =~ "GB")
	{
        $coding_value = "GBK"
    }
	my $ipaddr = $ARGV[0];
	my $xml_string = "";
	
	$xml_string .='<?xml version="1.0" encoding="'.$coding_value.'"?>'."\n";
	$xml_string .='<result>'."\n";
	$xml_string .= '<osName><![CDATA['."$os_name".']]></osName>'."\n";
	$xml_string .= '<version><![CDATA['."$os_version".']]></version>'."\n";
	$xml_string .= '<ip><![CDATA['."$ipaddr".']]></ip>'."\n";
	$xml_string .= '<type><![CDATA[/middleware/Apache]]></type>'."\n";
	$xml_string .= '<startTime><![CDATA['."$date".']]></startTime>'."\n";
	$xml_string .= '<pId><![CDATA[85]]></pId>'."\n";

	$xml_string .=	"\t".'<scripts>'."\n";
	
	foreach $key (@array_pre_flag)
	{
	    print $key."\n";
		$value = $pre_cmd{$key};
		my $tmp_result = $value.`$value`;
		chomp $tmp_result;
		$tmp_result =~ s/>/&gt;/g;
		$tmp_result =~ s/[\x00-\x08\x0b-\x0c\x0e-\x1f]//g;
		$xml_string = &add_item( $xml_string, $key, $tmp_result );
	}
	
	$xml_string .= "\t</scripts>\n";
	my $enddate = ` date "+%Y-%m-%d %H:%M:%S"`;
	$xml_string .= '<endTime><![CDATA['."$enddate".']]></endTime>'."\n";
	$xml_string .= "</result>"."\n";
	$xmlfile = $ipaddr."_"."Apache"."_chk.xml";
	print $xmlfile."\n";
	open XML,">$ENV{'PWD'}/".$xmlfile or die "Cannot create ip.xml:$!";
	print XML $xml_string;
    print "write  result to $ENV{'PWD'}/$xmlfile\n";
    print "execute end!\n";
}
generate_xml();
