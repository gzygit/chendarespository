#!env perl
#Author: autoCreated
my $para_num = "3";
my %para;
@array_pre_flag = ();
@array_appendix_flag = ();

#$para{PWD} = $ARGV[1];
$para{CONFIG_PATH} = $ARGV[1];
$para{SERVER_TYPE} = $ARGV[2];
#$para{USERS} = $ARGV[4];

$pre_cmd{2312} = "cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jmx-console.war/WEB-INF/jboss-web.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|grep -i \"<security-domain>\";
cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jmx-console.war/WEB-INF/web.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed -n \"/<security-constraint>/,/<\\/security-constraint>/p\";
";
push(@array_pre_flag, 2312);
$pre_cmd{2313} = "cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/management/console-mgr.sar/web-console.war/WEB-INF/jboss-web.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|grep -i \"<security-domain>\"
cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/management/console-mgr.sar/web-console.war/WEB-INF/web.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed -n \"/<security-constraint>/,/<\\/security-constraint>/p\"
";
push(@array_pre_flag, 2313);
$pre_cmd{2314} = "if [ -s  \"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jbossws.sar/jbossws-context.war/WEB-INF/web.xml\" ];
then
File1=\"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jbossws.sar/jbossws-context.war/WEB-INF/web.xml\";
elif [ -s  \"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jbossws.sar/jbossws-management.war/WEB-INF/web.xml\" ];
then
File1=\"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jbossws.sar/jbossws-management.war/WEB-INF/web.xml\";
fi;
if [ -s \"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jbossws.sar/jbossws-context.war/WEB-INF/jboss-web.xml\" ];
then
File2=\"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jbossws.sar/jbossws-context.war/WEB-INF/jboss-web.xml\";
elif [ -s \"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jbossws.sar/jbossws-management.war/WEB-INF/jboss-web.xml\" ];
then
File2=\"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jbossws.sar/jbossws-management.war/WEB-INF/jboss-web.xml\";
fi;
cat \"\$File1\" | sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed -n \"/<security-constraint>/,/<\\/security-constraint>/p\";
cat \"\$File2\" | sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|grep -i \"<security-domain>\";
unset File1 File2;
";
push(@array_pre_flag, 2314);
$pre_cmd{2315} = "jboss_dcredit=`cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/props/jmx-console-users.properties|sed \"/^\\s*#/d\"|awk -F= '{print \$2}'|grep \"[0-9]\"`;
jboss_lcredit=`cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/props/jmx-console-users.properties|sed \"/^\\s*#/d\"|awk -F= '{print \$2}'|grep \"[a-z]\"`;
jboss_ucredit=`cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/props/jmx-console-users.properties|sed \"/^\\s*#/d\"|awk -F= '{print \$2}'|grep \"[A-Z]\"`;
jboss_ocredit=`cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/props/jmx-console-users.properties|sed \"/^\\s*#/d\"|awk -F= '{print \$2}'|grep \"[^a-z0-9A-Z]\"`;
flag=0;
if [ -n \"\$jboss_dcredit\" ];
then
let flag++;
fi;
if [ -n \"\$jboss_lcredit\" ];
then
let flag++;
fi;
if [ -n \"\$jboss_ucredit\" ];
then
let flag++;
fi;
if [ -n \"\$jboss_ocredit\" ];
then
let flag++;
fi;
echo \"Password_complex=\$flag\"
unset jboss_dcredit jboss_lcredit jboss_ucredit jboss_ocredit flag;
";
push(@array_pre_flag, 2315);
$pre_cmd{2316} = "ps -ef|grep jboss|grep -v \"grep\"|awk '{print \$1}';
echo \"jboss_users=\"`ps -ef|grep jboss|grep -v \"grep\"|awk '{print \$1}'`;
";
push(@array_pre_flag, 2316);
$pre_cmd{2317} = "cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/props/jmx-console-roles.properties|sed \"/^\\s*#/d\"|awk -F= '{print \$2}'
for roles in  `cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/props/jmx-console-roles.properties|sed \"/^\\s*#/d\"|awk -F= '{print \$2}'`
do
echo \"user_roles=\"`echo \$roles|awk -F, '{for(i=1;i<=NF;i++) printf\"%s\\n\",\$i}'|wc -l`
done
unset roles
";
push(@array_pre_flag, 2317);
$pre_cmd{2318} = "cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/jboss-log4j.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed -n \"/<appender/,/<\\/appender>/p\"
";
push(@array_pre_flag, 2318);
$pre_cmd{2319} = "unset jboss_https jboss_keypath jboss_keypass;
if [ -s \"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jboss-web.deployer/server.xml\" ];
then
ssl_path=\"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jboss-web.deployer/server.xml\";
elif [ -s \"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jbossweb.sar/server.xml\" ];
then
ssl_path=\"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jbossweb.sar/server.xml\";
fi;
jboss_https=`cat \"\$ssl_path\" | sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d' | sed -n \"/scheme\\s*=\\s*\\\"https\\\"/p\"`;
jboss_keypath=`cat \"\$ssl_path\" | sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d' | grep 'keystoreFile='`;
jboss_keypass=`cat \"\$ssl_path\" | sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d' | grep 'keystorePass='`;
if [[ -n \"\$jboss_https\" && -n \"\$jboss_keypath\" && -n \"\$jboss_keypass\" ]];
then
echo \"https:enable\";
else
echo \"https:disable\";
fi
unset jboss_https jboss_keypath jboss_keypass ssl_path;
";
push(@array_pre_flag, 2319);
$pre_cmd{2320} = "if [ -s \"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jboss-web.deployer/server.xml\" ];
then
server_path=\"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jboss-web.deployer/server.xml\";
elif [ -s \"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jbossweb.sar/server.xml\" ];
then
server_path=\"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jbossweb.sar/server.xml\";
fi;
cat \$server_path|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|grep \"port\"|grep -v \"AJP\"
";
push(@array_pre_flag, 2320);
$pre_cmd{2321} = "if [ -s \"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jboss-web.deployer/server.xml\" ];
then
server_path=\"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jboss-web.deployer/server.xml\";
elif [ -s \"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jbossweb.sar/server.xml\" ];
then
server_path=\"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jbossweb.sar/server.xml\";
fi;
cat \$server_path|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|grep \"connectionTimeout\"
";
push(@array_pre_flag, 2321);
$pre_cmd{2322} = "if [ -s $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jboss-web.deployer/ROOT.war/WEB-INF/web.xml ];
then
web_xml=\"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jboss-web.deployer/ROOT.war/WEB-INF/web.xml\";
elif [ -s $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/ROOT.war/WEB-INF/web.xml ];
then
web_xml=\"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/ROOT.war/WEB-INF/web.xml\";
fi;
cat \$web_xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed -n \"/<servlet-mapping>/,/<\\/servlet-mapping>/p\"
unset web_xml
";
push(@array_pre_flag, 2322);
$pre_cmd{2323} = "if [ -s \"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jboss-web.deployer/conf/web.xml\" ];
then
web_xml=\"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jboss-web.deployer/conf/web.xml\";
elif [ -s \"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jbossws.sar/jbossws-management.war/WEB-INF/web.xml\" ];
then
web_xml=\"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jbossws.sar/jbossws-management.war/WEB-INF/web.xml\";
fi
cat \$web_xml |  sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed -n \"/<welcome-file-list/,/<\\/welcome-file-list>/p\"
unset web_xml
";
push(@array_pre_flag, 2323);
$pre_cmd{2324} = "if [ -s $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jboss-web.deployer/conf/web.xml ];
then
web_xml=\"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/jboss-web.deployer/conf/web.xml\";
elif [ -s $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deployers/jbossweb.deployer/web.xml ];
then
web_xml=\"$para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deployers/jbossweb.deployer/web.xml\";
fi
cat \"\$web_xml\"| sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d' |sed -n \"/<servlet>/,/<\\/servlet>/p\"
";
push(@array_pre_flag, 2324);
$pre_cmd{2325} = "echo \"jmx-console_length=\"`cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/props/jmx-console-users.properties | sed \"/^\\s*#/d\" | awk -F= '{print \$2}'| wc -L`;
echo \"web-console_length=\"`cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/management/console-mgr.sar/web-console.war/WEB-INF/classes/web-console-users.properties | sed \"/^\\s*#/d\" | awk -F= '{print \$2}'| wc -L`;
jboss_dcredit=`cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/props/jmx-console-users.properties|sed \"/^\\s*#/d\"|awk -F= '{print \$2}'|grep \"[0-9]\"`;
jboss_lcredit=`cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/props/jmx-console-users.properties|sed \"/^\\s*#/d\"|awk -F= '{print \$2}'|grep \"[a-z]\"`;
jboss_ucredit=`cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/props/jmx-console-users.properties|sed \"/^\\s*#/d\"|awk -F= '{print \$2}'|grep \"[A-Z]\"`;
jboss_ocredit=`cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/props/jmx-console-users.properties|sed \"/^\\s*#/d\"|awk -F= '{print \$2}'|grep \"[^a-z0-9A-Z]\"`;
flag=0;
if [ -n \"\$jboss_dcredit\" ];
then
let flag++;
fi;
if [ -n \"\$jboss_lcredit\" ];
then
let flag++;
fi;
if [ -n \"\$jboss_ucredit\" ];
then
let flag++;
fi;
if [ -n \"\$jboss_ocredit\" ];
then
let flag++;
fi;
echo \"Password_complex_jmx-console=\$flag\"
unset jboss_dcredit jboss_lcredit jboss_ucredit jboss_ocredit flag;
jboss_dcredit1=`cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/management/console-mgr.sar/web-console.war/WEB-INF/classes/web-console-users.properties | sed \"/^\\s*#/d\" | awk -F= '{print \$2}'| grep \"[0-9]\"`;
jboss_lcredit1=`cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/management/console-mgr.sar/web-console.war/WEB-INF/classes/web-console-users.properties | sed \"/^\\s*#/d\" | awk -F\\\\= '{print \$2}'| grep \"[a-z]\"`;
jboss_ucredit1=`cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/management/console-mgr.sar/web-console.war/WEB-INF/classes/web-console-users.properties | sed \"/^\\s*#/d\" | awk -F\\\\= '{print \$2}'| grep \"[A-Z]\"`;
jboss_ocredit1=`cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/deploy/management/console-mgr.sar/web-console.war/WEB-INF/classes/web-console-users.properties | sed \"/^\\s*#/d\" | awk -F\\\\= '{print \$2}'| grep \"[^a-z0-9A-Z]\"`;
flag1=0;
if  [ -n \"\$jboss_dcredit1\" ];
then
let flag1++;
fi
if  [ -n \"\$jboss_lcredit1\" ];
then
let flag1++;
fi
if  [ -n \"\$jboss_ucredit1\" ];
then
let flag1++;
fi
if  [ -n \"\$jboss_ocredit1\" ];
then
let flag1++;
fi
echo \"Password_complex_web-console=\$flag1\"
unset jboss_dcredit1 jboss_lcredit1 jboss_ucredit1 jboss_ocredit1 flag1;
";
push(@array_pre_flag, 2325);
$pre_cmd{-17} = "cat  $para{CONFIG_PATH}/jar-versions.xml |grep \"antlr.jar\"
";
push(@array_pre_flag, -17);
$pre_cmd{-18} = "cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/jboss-service.xml |grep \"ThreadGroupName\"
";
push(@array_pre_flag, -18);
$pre_cmd{-19} = "cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/jboss-service.xml |grep \"KeepAliveTime\"
";
push(@array_pre_flag, -19);
$pre_cmd{-20} = "cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/jboss-service.xml |grep \"MaximumPoolSize\"
";
push(@array_pre_flag, -20);
$pre_cmd{-21} = "cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/jboss-service.xml |grep \"MaximumQueueSize\"
";
push(@array_pre_flag, -21);
$pre_cmd{-22} = "cat $para{CONFIG_PATH}/server/$para{SERVER_TYPE}/conf/props/jmx-console-roles.properties
";
push(@array_pre_flag, -22);


$pre_cmd{11712} = "rm -f /tmp/awkxmlfilter /tmp/c213 temconn211 rm -f tmp129 rm -f /tmp/port956";
push(@array_pre_flag, 0);

sub get_os_info
{
	my %os_info = (
 "initSh"=>"","hostname"=>"","osname"=>"","osversion"=>"");
 $os_info{"initSh"} = `unset LANG`;
	$os_info{"hostname"} = `uname -n`;
	$os_info{"osname"} = `uname -s`;
	$os_info{"osversion"} = `lsb_release -a;cat /etc/issue;cat /etc/redhat-release;uname -a`;
	foreach (%os_info){   chomp;}
	return %os_info;
}

sub add_item
{
	my ($string, $flag, $value)= @_;
	$string .= "\t\t".'<script>'."\n";
	$string .= "\t\t\t<id>$flag</id>\n";
	$string .= "\t\t\t<value><![CDATA[$value]]></value>\n";
	$string .= "\t\t</script>\n";
	return $string;
}
sub generate_xml
{
	$ARGC = @ARGV;
	if($ARGC lt 3)
	{
		print qq{usag:uuid.pl IP   �����ļ�����Ŀ¼  ����������};
		exit;
	}
	my %os_info = get_os_info();
	my $os_name = $os_info{"osname"};
	my $host_name = $os_info{"hostname"};
	my $os_version = $os_info{"osversion"};
	my $date = `date "+%Y-%m-%d %H:%M:%S"`;
	chomp $date;
	my $coding = `echo \$LANG`;
	my $coding_value = "UTF-8";
	chomp $coding;
	if($coding =~ "GB")
	{
        $coding_value = "GBK"
    }
	my $ipaddr = $ARGV[0];
	my $xml_string = "";
	
	$xml_string .='<?xml version="1.0" encoding="'.$coding_value.'"?>'."\n";
	$xml_string .='<result>'."\n";
	$xml_string .= '<osName><![CDATA['."$os_name".']]></osName>'."\n";
	$xml_string .= '<version><![CDATA['."$os_version".']]></version>'."\n";
	$xml_string .= '<ip><![CDATA['."$ipaddr".']]></ip>'."\n";
	$xml_string .= '<type><![CDATA[/middleware/Jboss]]></type>'."\n";
	$xml_string .= '<startTime><![CDATA['."$date".']]></startTime>'."\n";
	$xml_string .= '<pId><![CDATA[87]]></pId>'."\n";
	
	$xml_string .=	"\t".'<scripts>'."\n";
	
	foreach $key (@array_pre_flag)
	{
	    print $key."\n";
		$value = $pre_cmd{$key};
		my $tmp_result = $value.`$value`;
		chomp $tmp_result;
		$tmp_result =~ s/>/&gt;/g;
		$tmp_result =~ s/[\x00-\x08\x0b-\x0c\x0e-\x1f]//g;
		$xml_string = &add_item( $xml_string, $key, $tmp_result );
	}
	$xml_string .= "\t</scripts>\n";
	my $enddate = ` date "+%Y-%m-%d %H:%M:%S"`;
	$xml_string .= '<endTime><![CDATA['."$enddate".']]></endTime>'."\n";
	$xml_string .= "</result>"."\n";
	$xmlfile = $ipaddr."_"."middleware_linux_jboss"."_chk.xml";
	print $xmlfile."\n";
	open XML,">$ENV{'PWD'}/".$xmlfile or die "Cannot create ip.xml:$!";
	print XML $xml_string;
    print "write  result to $ENV{'PWD'}/$xmlfile\n";
    print "execute end!\n";
}
generate_xml();
