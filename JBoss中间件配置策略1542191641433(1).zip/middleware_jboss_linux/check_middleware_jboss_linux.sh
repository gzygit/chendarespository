#!/bin/sh
[ $# -ne 3 ] && { 
 echo "Usage: sh check_middleware_jboss_linux.sh IP  配置文件所在目录  jboss服务类型";
 exit 1;
}

pathname=`pwd`
perl $pathname/check_middleware_jboss_linux.pl "${1}" "${2}" "${3}"
