1.解压缩下载的脚本包,成功后能看到名称为check_middleware_jboss_windows.vbs的脚本，将脚本拷贝至被核查主机.
2.双击解压缩后的VB脚本:check_middleware_jboss_windows.vbs,按提示依次输入jboss安装路径,jboss服务器类型.
(说明:2.1.jboss安装路径:配置为$InstallHomePath的值: $InstallHomePath\server\default)
3.脚本执行完成后会在当前目录生成一个xml格式的结果文件,xml结果文件或者将该xml文件压缩成的zip格式文件,可以导入系统.
4.注意一定不要修改离线工具默认的执行方式.
