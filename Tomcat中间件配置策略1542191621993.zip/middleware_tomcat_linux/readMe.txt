1.解压缩下载的脚本包,成功后能看到名称为check_middleware_tomcat_linux.pl和check_middleware_tomcat_linux.sh的脚本，将脚本拷贝至被核查主机.
2.如要对IP为192.168.1.1的设备进行核查,请在终端下执行如下命令:"sh check_middleware_tomcat_linux.sh 192.168.1.1  tomcat安装路径"
(说明:2.1.tomcat安装路径:安装路径配置为$InstallHomePath的值 $InstallHomePath/conf/server.xml.)
3.脚本执行完成后会在当前目录生成一个xml格式的结果文件,xml结果文件或者将该xml文件压缩成的zip格式文件,可以导入系统.
4.注意一定不要修改离线工具默认的执行方式.
