#!env perl
#Author: autoCreated
my $para_num = "2";
my %para;
@array_pre_flag = ();
@array_appendix_flag = ();

#$para{PWD} = $ARGV[1];
$para{CONFIG_PATH} = $ARGV[1];
#$para{USERVIP} = $ARGV[3];
#$para{USERS} = $ARGV[4];

$pre_cmd{1901} = "cat $para{CONFIG_PATH}/conf/tomcat-users.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed '/^\\s*\$/d'
";
push(@array_pre_flag, 1901);
$pre_cmd{1903} = "cat $para{CONFIG_PATH}/conf/tomcat-users.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'
";
push(@array_pre_flag, 1903);
$pre_cmd{1904} = "cat $para{CONFIG_PATH}/conf/server.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed '/^\\s*\$/d'|grep \"connectionTimeout\"
";
push(@array_pre_flag, 1904);
$pre_cmd{1906} = "cat $para{CONFIG_PATH}/conf/server.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed '/^\\s*\$/d'|grep \"keystoreFile\"
";
push(@array_pre_flag, 1906);
$pre_cmd{1907} = "cat $para{CONFIG_PATH}/conf/web.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed '/^\\s*\$/d'|sed -n  \"/<error-page>/,/<\\/error-page>/p\"
";
push(@array_pre_flag, 1907);
$pre_cmd{1909} = "cat $para{CONFIG_PATH}/conf/tomcat-users.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed '/^\\s*\$/d'
";
push(@array_pre_flag, 1909);
$pre_cmd{1910} = "cat $para{CONFIG_PATH}/conf/tomcat-users.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed '/^\\s*\$/d'|grep \"username=\"|awk '{print \$2}'|cut -d\\\" -f2
echo \"user_count=\"`cat $para{CONFIG_PATH}/conf/tomcat-users.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed '/^\\s*\$/d'|grep \"username=\"|awk '{print \$2}'|cut -d\\\" -f2|wc -l`
";
push(@array_pre_flag, 1910);
$pre_cmd{1911} = "cat $para{CONFIG_PATH}/conf/server.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed \"/^\\s*\$/d\"|grep -i \"port\"|grep -v -i \"AJP\"
";
push(@array_pre_flag, 1911);
$pre_cmd{1912} = "cat $para{CONFIG_PATH}/conf/web.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed '/^\\s*\$/d'|sed -n  \"/<init-param>/,/<\\/init-param>/p\"
";
push(@array_pre_flag, 1912);
$pre_cmd{1913} = "cat $para{CONFIG_PATH}/conf/server.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed '/^\\s*\$/d'|sed -n \"/<Host/,/<\\/Host>/p\"
";
push(@array_pre_flag, 1913);
$pre_cmd{1914} = "cat $para{CONFIG_PATH}/conf/server.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed \"/^\\s*\$/d\"|grep \"shutdown\"
";
push(@array_pre_flag, 1914);
$pre_cmd{1915} = "cat $para{CONFIG_PATH}/conf/server.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed '/^\\s*\$/d'
";
push(@array_pre_flag, 1915);
$pre_cmd{1916} = "cat $para{CONFIG_PATH}/conf/web.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed -n \"/org.apache.catalina.servlets.DefaultServlet/,/<\\/servlet>/p\"
";
push(@array_pre_flag, 1916);
$pre_cmd{1917} = "ps -ef|grep -i \"org.apache.catalina.startup.Bootstrap\"|grep -v \"grep\"|awk '{print \$1}'
echo \"user=\"`ps -ef|grep -i \"org.apache.catalina.startup.Bootstrap\"|grep -v \"grep\"|awk '{print \$1}'`
";
push(@array_pre_flag, 1917);
$pre_cmd{1918} = "$para{CONFIG_PATH}/bin/version.sh
";
push(@array_pre_flag, 1918);
$pre_cmd{-11} = "sh $para{CONFIG_PATH}/bin/version.sh
";
push(@array_pre_flag, -11);
$pre_cmd{-12} = "cat $para{CONFIG_PATH}/conf/server.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'|sed '/^\\s*\$/d'
";
push(@array_pre_flag, -12);
$pre_cmd{-13} = "cat $para{CONFIG_PATH}/conf/tomcat-users.xml|sed '/<!--.*-->/d'|sed '/^\$/d'|sed '/<!--/,/-->/d'
";
push(@array_pre_flag, -13);


sub get_os_info
{
	my %os_info = (
 "initSh"=>"","hostname"=>"","osname"=>"","osversion"=>"");
 $os_info{"initSh"} = `unset LANG`;
	$os_info{"hostname"} = `uname -n`;
	$os_info{"osname"} = `uname -s`;
	$os_info{"osversion"} = `lsb_release -a;cat /etc/issue;cat /etc/redhat-release;uname -a`;
	foreach (%os_info){   chomp;}
	return %os_info;
}

sub add_item
{
	my ($string, $flag, $value)= @_;
	$string .= "\t\t".'<script>'."\n";
	$string .= "\t\t\t<id>$flag</id>\n";
	$string .= "\t\t\t<value><![CDATA[$value]]></value>\n";
	$string .= "\t\t</script>\n";
	return $string;
}
sub generate_xml
{
	$ARGC = @ARGV;
	if($ARGC lt 2)
	{
		print qq{usag:uuid.pl IP  �����ļ�����Ŀ¼ };
		exit;
	}
	my %os_info = get_os_info();
	my $os_name = $os_info{"osname"};
	my $host_name = $os_info{"hostname"};
	my $os_version = $os_info{"osversion"};
	my $date = `date "+%Y-%m-%d %H:%M:%S"`;
	chomp $date;
	my $coding = `echo \$LANG`;
	my $coding_value = "UTF-8";
	chomp $coding;
	if($coding =~ "GB")
	{
        $coding_value = "GBK"
    }
	my $ipaddr = $ARGV[0];
	my $xml_string = "";
	
	$xml_string .='<?xml version="1.0" encoding="'.$coding_value.'"?>'."\n";
	$xml_string .='<result>'."\n";
	$xml_string .= '<osName><![CDATA['."$os_name".']]></osName>'."\n";
	$xml_string .= '<version><![CDATA['."$os_version".']]></version>'."\n";
	$xml_string .= '<ip><![CDATA['."$ipaddr".']]></ip>'."\n";
	$xml_string .= '<type><![CDATA[/middleware/Tomcat]]></type>'."\n";
	$xml_string .= '<startTime><![CDATA['."$date".']]></startTime>'."\n";
	$xml_string .= '<pId><![CDATA[83]]></pId>'."\n";
	
	$xml_string .=	"\t".'<scripts>'."\n";
	
	foreach $key (@array_pre_flag)
	{
	    print $key."\n";
		$value = $pre_cmd{$key};
		my $tmp_result = $value.`$value`;
		chomp $tmp_result;
		$tmp_result =~ s/>/&gt;/g;
		$tmp_result =~ s/[\x00-\x08\x0b-\x0c\x0e-\x1f]//g;
		$xml_string = &add_item( $xml_string, $key, $tmp_result );
	}
	$xml_string .= "\t</scripts>\n";
	my $enddate = ` date "+%Y-%m-%d %H:%M:%S"`;
	$xml_string .= '<endTime><![CDATA['."$enddate".']]></endTime>'."\n";
	$xml_string .= "</result>"."\n";
	$xmlfile = $ipaddr."_"."middleware_linux_tomcat"."_chk.xml";
	print $xmlfile."\n";
	open XML,">$ENV{'PWD'}/".$xmlfile or die "Cannot create ip.xml:$!";
	print XML $xml_string;
    print "write  result to $ENV{'PWD'}/$xmlfile\n";
    print "execute end!\n";
}
generate_xml();
