#!/bin/sh
[ $# -ne 2 ] && { 
 echo "Usage: sh check_middleware_apache_linux.sh IP  Apache安装路径";
 exit 1;
}
pathname=`pwd`
perl $pathname/check_middleware_apache_linux.pl "${1}" "${2}" 