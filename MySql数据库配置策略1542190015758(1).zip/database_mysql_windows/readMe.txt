1.解压缩下载的脚本包,成功后能看到名称为check_database_mysql_windows.vbs的VB脚本，将该脚本拷贝至被核查主机.
2.双击解压缩后的VB脚本:check_database_mysql_windows.vbs,按提示依次输入数据库用户,数据库密码,端口号 ,数据库配置文件mysql.exe路径(如C:\MYSQL\mysql.exe).
(说明:2.1.系统内置mysql脚本无需检查mysql配置文件,所以my.ini路径参数不需要配置,可以使用""替代或不填写;
      2.2.数据库用户,数据库密码,端口号可为空,不填写.)
3.脚本执行完成后会在当前目录生成一个xml格式的结果文件,xml结果文件或者将该xml文件压缩成的zip格式文件,可以导入系统.
4.注意一定不要修改离线工具默认的执行方式.
